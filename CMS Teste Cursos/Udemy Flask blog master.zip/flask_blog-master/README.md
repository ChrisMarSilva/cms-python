Video link here: https://youtu.be/XHGpPCYmPvI
